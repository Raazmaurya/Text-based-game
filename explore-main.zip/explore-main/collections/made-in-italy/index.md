---
items:
 - fastify/fastify
 - immuni-app/immuni
 - italia/covid19-opendata-vaccini
 - middyjs/middy
 - nodejs/undici
 - elastic/elasticsearch-js
 - morrolinux/simple-ehm
 - micheleriva/coronablocker
 - HospitalRun/hospitalrun
 - histolab/histolab
 - strawberry-graphql/strawberry
 - notable/notable
 - federico-terzi/espanso
 - eciavatta/caronte
 - Schrodinger-Hat/ImageGoNord
 - stoplightio/prism
display_name: Made in Italy
created_by: thejoin95
image: made-in-italy.png
---
Open source projects built in or receiving significant contributions from Italy :it:
