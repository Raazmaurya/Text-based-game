---
items:
 - GliaX/Stethoscope
 - HospitalRun/hospitalrun-frontend
 - get-alex/alex
 - coralproject/talk
 - hotosm/tasking-manager
 - OptiKey/OptiKey
 - ifmeorg/ifme
 - RefugeRestrooms/refugerestrooms
 - hurricane-response/florence-api
 - Terrastories/terrastories
 - rubyforgood/diaper
 - rubyforgood/playtime
 - rubyforgood/demand-progress
 - ebimodeling/ghgvc
 - raksha-life/rescuekerala
 - Data4Democracy/ethics-resources
 - civicdata/civicdata.github.io
 - yunity/karrot-frontend
display_name: Social Impact
created_by: bescalante
---
Improving our world through open source technology
