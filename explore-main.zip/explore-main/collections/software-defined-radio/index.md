---
items:
 - gnuradio/gnuradio
 - gnuradio/volk
 - csete/gqrx
 - jgaeddert/liquid-dsp
 - miek/inspectrum
 - kpreid/shinysdr
 - RangeNetworks/openbts
 - srsRAN/srsRAN
 - xmikos/qspectrumanalyzer
 - cjcliffe/CubicSDR
 - jopohl/urh
 - https://www.youtube.com/embed/kWfU1G3Jq4w
display_name: Software Defined Radio
created_by: jbjonesjr
---
Interested in Software for Wireless Communications? This is the place.
