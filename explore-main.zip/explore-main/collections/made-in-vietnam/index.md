---
items:
 - mlbvn
 - VinAIResearch
 - vietai
 - webuild-community
 - chiphuyen/machine-learning-systems-design
 - tiepvupsu/ebookMLCB
 - holistics/dbml
 - google/edward2
 - vncorenlp/VnCoreNLP
 - google/tink
 - blei-lab/edward
 - ZuzooVn/machine-learning-for-software-engineers
 - chiphuyen/ml-interviews-book
 - huytd/kanban-app
 - undertheseanlp/underthesea
 - tiepvupsu/tabml_book
 - hoanhan101/algo
 - vinbigdata-medical/vindr-lab
 - vanhuyz/CycleGAN-TensorFlow
 - TablePlus/TablePlus
 - khangich/machine-learning-interview
 - huytd/agar.io-clone
 - opencardev/crankshaft
 - binhnguyennus/awesome-scalability
 - hoanhan101/ultimate-go
 - ProxymanApp/Proxyman
 - bangoc123/learn-machine-learning-in-two-months
 - phuoc-ng/csslayout
 - nguyenquangminh0711/ruby_jard
 - phuoc-ng/1loc
 - BambooEngine/ibus-bamboo
display_name: Made in Vietnam
created_by: duythanhvn
image: made-in-vietnam.png
---
Open source projects built in or receiving significant contributions from Vietnam :vietnam:
