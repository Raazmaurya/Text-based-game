---
items:
 - 30-seconds/30-seconds-of-code
 - railsgirls/railsgirls.github.io
 - railsbridge/docs
 - freeCodeCamp/freeCodeCamp
 - leachim6/hello-world
 - datasciencemasters/go
 - tuvtran/project-based-learning
 - zhiwehu/Python-programming-exercises
 - MunGell/awesome-for-beginners
 - appacademy/welcome-to-open
 - webgems/webgems
 - kamranahmedse/developer-roadmap
 - AMAI-GmbH/AI-Expert-Roadmap
 - trekhleb/javascript-algorithms
 - Microsoft/web-dev-for-beginners
 - karan/Projects
 - sindresorhus/awesome
 - donnemartin/system-design-primer
 - danistefanovic/build-your-own-x
 - public-apis/public-apis
 - EbookFoundation/free-programming-books
 - amitness/learning
 - mhinz/vim-galore
 - tayllan/awesome-algorithms
 - karlhorky/learn-to-program
 - therebelrobot/awesome-workshopper
 - jlevy/the-art-of-command-line
 - papers-we-love/papers-we-love
 - awesome-selfhosted/awesome-selfhosted
 - ripienaar/free-for-dev
 - gothinkster/realworld
 - thedaviddias/Front-End-Checklist

display_name: Learn to Code
created_by: alysonla
image: learn-to-code.png
---
Resources to help people learn to code
