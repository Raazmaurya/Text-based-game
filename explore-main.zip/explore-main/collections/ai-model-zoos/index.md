---
items:
 - tensorflow/models
 - Theano/Theano
 - BVLC/caffe
 - caffe2/models
 - apache/incubator-mxnet
 - eclipse/deeplearning4j
 - sdhnshu/pytorch-model-zoo
 - Lasagne/Recipes
 - albertomontesg/keras-model-zoo
 - hindupuravinash/the-gan-zoo
 - likedan/Awesome-CoreML-Models
 - Microsoft/CNTK
display_name: Model Zoos of machine and deep learning technologies
created_by: alanbraz
---
Model Zoo is a common way that open source frameworks and companies organize their machine learning and deep learning models.
