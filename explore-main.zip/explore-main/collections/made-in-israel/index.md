---
items:
 - yaronn/blessed-contrib
 - getredash/redash
 - cool-RR/PySnooper
 - wix/react-native-navigation
 - linnovate/mean
 - appwrite/appwrite
 - snyk/snyk
 - ealush/vest
 - aantn/smag
 - lirantal/licenseye
 - lirantal/dockly
 - eranroz/HspellPy
display_name: Made in Israel
created_by: donno2048
image: made-in-israel.png
---
Open source projects built in Israel :israel:
