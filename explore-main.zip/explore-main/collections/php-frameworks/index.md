---
items:
 - laravel/laravel
 - symfony/symfony
 - bcit-ci/CodeIgniter
 - slimphp/Slim
 - yiisoft/yii
 - cakephp/cakephp
 - dinophp/dinophp
display_name: PHP Frameworks
created_by: Ahmed-Ibrahimm
---
While the number of ways to organize PHP is almost infinite, here are some frameworks that help you build clean applications.