---
items:
 - github/lightcrawler
 - Khan/tota11y
 - addyosmani/a11y
 - ffoodd/a11y.css
 - jxnblk/colorable
 - brunopulis/awesome-a11y
 - medialize/ally.js
 - aduggin/accessibility-fails
 - pa11y/pa11y
 - Heydon/REVENGE.CSS
 - reactjs/react-a11y
 - angular/protractor-accessibility-plugin
 - AccessLint/accesslint.js
 - 18F/accessibility
 - prettydiff/a11y-tools
 - dequelabs/axe-cli
 - stevefaulkner/HTML5accessibility
 - liip/TheA11yMachine
 - a11yproject/a11yproject.com
 - GoogleChrome/accessibility-developer-tools
 - GoogleChrome/lighthouse
 - fejes713/accessibility-guide
 - adobe/leonardo
 - ZingGrid/zinggrid
display_name: Web accessibility
created_by: muan
---
Tools to help you design and develop web projects with accessibility in mind.
