---
items:
 - mirumee/saleor
 - callstack
 - software-mansion/react-native-reanimated
 - jsfiddle
 - impress/impress.js
 - sindresorhus/got
 - mirumee/ariadne
 - chaps-io/public_activity
 - YetiForceCompany/YetiForceCRM
 - razorjack/quicksand
 - handsontable/handsontable
 - oskarkrawczyk/heyoffline
 - sickill/git-dude
 - damian-kolakowski/iOS-Hierarchy-Viewer
 - sickill/bitpocket
 - bernii/gauge.js
 - wuub/SublimeREPL
 - kamilkisiela/graphql-config

display_name: Made in Poland
created_by: Tymek
image: made-in-poland.png
---
Open source projects built in or receiving significant contributions from Poland :poland:
