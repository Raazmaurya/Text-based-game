---
items:
 - twbs/bootstrap
 - foundation/foundation-sites
 - jgthms/bulma
 - uikit/uikit
 - semantic-org/semantic-ui
 - Dogfalo/materialize
 - pure-css/pure
 - tailwindlabs/tailwindcss
display_name: CSS Frameworks
created_by: krishdevdb
---
A CSS framework is a set of css classes that allow you to create your website with little to no new css code.
