---
items:
 - TheAlgorithms
 - hoppscotch/hoppscotch
 - anuraghazra/github-readme-stats
 - hasura/graphql-engine
 - geekyants/nativebase
 - kovidgoyal/calibre
 - frappe/erpnext
 - chatwoot/chatwoot
 - openebs/openebs  
 - fission/fission
 - covid19india/covid19india-react
 - knadh/listmonk
 - appsmithorg/appsmith
 - bagisto/bagisto
 - gluster/glusterfs
 - frappe/frappe
 - spacecloud-io/space-cloud
 - shivammathur/setup-php
 - infracloudio/botkube
 - SigNoz/signoz
 - uvdesk/community-skeleton
 - CRED-CLUB/synth-android
 - resetercss/reseter.css
 - pupilfirst/pupilfirst
 - kadalu/kadalu
 - project-sunbird
 - composewell/streamly
 - SecurityFTW/cs-suite
 - adithyakhamithkar/ansible-playbooks
 - ToolJet/ToolJet
 - ParthJadhav/Tkinter-Designer
 - dr5hn/countries-states-cities-database
 - glific/glific
 - gautamkrishnar/blog-post-workflow
 - devtron-labs/devtron
 - skytable/skytable
 - firstcontributions/first-contributions
 - CircuitVerse/CircuitVerse
 - mayankmetha/Rucky
display_name: Made in India
created_by: mvkaran
image: made-in-india.png
---
Open source projects built in or receiving significant contributions from India :india:
