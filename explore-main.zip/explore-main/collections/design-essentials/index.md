---
items:
 - twbs/bootstrap
 - daneden/animate.css
 - nathansmith/960-Grid-System
 - necolas/normalize.css
 - ionic-team/ionicons
 - designmodo/Flat-UI
 - h5bp/html5-boilerplate
 - foundation/foundation-sites
 - Modernizr/Modernizr
 - twbs/ratchet
 - IanLunn/Hover
 - connors/photon
 - basscss/basscss
 - atlemo/SubtlePatterns
 - mrmrs/colors
display_name: Design essentials
created_by: jonrohan
---
This collection of design libraries are the best on the web, and will complete your toolset for designing stunning products.
