---
items:
 - scdesktop/scdesktop

display_name: Made in Kazakhstan
created_by: snxx-lppxx
image: made-in-kazakhstan.png
---
Open source projects built in or receiving significant contributions from Kazakhstan :kazakhstan:
