---
items:
 - zerobias/effector
 - mobxjs/mobx
 - reduxjs/redux
 - Yomguithereal/baobab
 - immerjs/immer
 - davidkpiano/xstate
 - cerebral/cerebral
 - storeon/storeon
 - artalar/reatom
display_name: JavaScript State Management Tools
created_by: lestad
---
Framework agnostic libraries to manage state in JavaScript applications.
