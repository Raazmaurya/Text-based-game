---
items:
 - rust-lang/rust
 - HospitalRun/hospitalrun-frontend
 - hoodiehq/hoodie
 - Homebrew/brew
 - https://www.youtube.com/embed/dSl_qnWO104
 - public-apis/public-apis
display_name: How to choose (and contribute to) your first open source project
created_by: kytrinyx
---
New to open source? Here’s how to find projects that need help and start making impactful contributions.
