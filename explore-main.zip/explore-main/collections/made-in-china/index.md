---
items:
 - alibaba/arthas
 - alibaba/p3c
 - alibaba/druid
 - alibaba/fastjson
 - alibaba/flutter-go
 - tencent/weui
 - tencent/wepy
 - tencent/tinker
 - tencent/mars
 - tencent/weui-wxss
 - tencent/vConsole
 - tencent/QMUI_Android
 - tencent/MMKV
 - tencent/omi
 - tencent/ncnn
 - tencent/VasSonic
 - tencent/rapidjson
 - tencent/APIJSON
 - baidu/amis
 - baidu/san
 - baidu/uid-generator
 - CHINA-JD/presto
 - ElemeFE/element
 - ElemeFE/mint-ui
 - ElemeFE/node-interview
 - ElemeFE/v-charts
 - apolloconfig/apollo
 - netease/pomelo
 - meituan-dianping/mpvue
 - meituan-dianping/walle
 - dianping/cat
 - xiaomi/soar
 - xiaomi/mace
 - didi/DoraemonKit
 - didi/cube-ui
 - didi/chameleon
 - didi/VirtualAPK
 - Bilibili/ijkplayer
 - Bilibili/flv.js
 - Bilibili/DanmakuFlameMaster
display_name: Made in China
created_by: renfei
image: made-in-china.png
---
Open source projects built in or receiving significant contributions from China :cn:
