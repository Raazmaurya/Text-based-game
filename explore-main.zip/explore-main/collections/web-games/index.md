---
items:
 - gabrielecirulli/2048
 - ellisonleao/clumsy-bird
 - mozilla/BrowserQuest
 - AlexNisnevich/untrusted
 - doublespeakgames/adarkroom
 - Hextris/hextris
display_name: Web games
created_by: leereilly
---
Have some fun with these open source games.
