---
items:
 - Dreamacro/clash
 - Psiphon-Inc/psiphon
 - getlantern/lantern
 - shadowsocks/shadowsocks
 - trojan-gfw/trojan
 - v2fly/v2ray-core
display_name: Internet Censorship Circumventions
created_by: new-pac
---
Internet censorship circumvention is the use of various methods and tools to bypass internet censorship.
