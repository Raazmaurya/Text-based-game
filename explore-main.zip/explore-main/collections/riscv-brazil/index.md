---
items:
 - darklife/darkriscv
 - zxmarcos/riscado-v
 - racerxdl/riskow
 - duinos/riscuinho
display_name: Risc-V Cores Made in Brazil
created_by: carlosdelfino 
---

Projects related to RISC-V cores built or receiving significant contributions from Brazilians.
