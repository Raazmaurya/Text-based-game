---
items:
 - rubygarage/nextjs6-graphql-client-tutorial
 - MikeBild/serverless-aws-cdk-ecommerce
 - alexander-elgin/atomic-react-redux
 - fernandohenriques/chat-app
 - marcelorl/tastin-front
 - kumiko-haraguchi/live-jazz-tokyo
 - JoshEvan/StockManagementSystem
 - yudwig/next-redux-todo
 - atomixinteractions/materialized
 - takanassyi/react-and-rekognition
 - takanassyi/react-tutorial-ts-mui
 - pureinx/crowdmeeting
 - ERS-HCL/react-atomic-lib
display_name: Material-UI Projects Using Atomic Design
created_by: trentschnee
---
Find examples of projects utilizing Material-UI with the infamous atomic design system!