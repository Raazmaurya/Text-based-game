---
aliases: digital-image-processing
display_name: Image processing
related: computer-vision, vision, deep-learning, opencv
short_description: Digital image processing is the use of algorithms to make computers understand the image content.
topic: image-processing
wikipedia_url: https://en.wikipedia.org/wiki/Digital_image_processing
---
Digital image processing is the use of algorithms to make computers analyze the content of digital images.
