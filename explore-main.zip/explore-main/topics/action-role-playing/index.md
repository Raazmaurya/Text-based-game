---
display_name: action-role-playing
topic: action-role-playing
aliases: arpg, action-role-playing-game
related: action-game, role-playing-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Action_role-playing_game
---
A subgenre of role-playing video games emphasizing real-time combat, where the player has direct control over the characters as opposed to turn or menu-based combat.