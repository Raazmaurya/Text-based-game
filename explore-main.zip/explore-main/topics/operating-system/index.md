---
aliases: os, operating-systems, operating-systems-tutorials, operating-system-examples
display_name: Operating system
short_description: An operating system is a program that manages a computer's programs
  and applications.
topic: operating-system
wikipedia_url: https://en.wikipedia.org/wiki/Operating_system
---
An operating system operates and manages both the hardware and software in a computer. Operating systems provide software platforms for applications to function.
