---
created_by: Damien Elmes
display_name: Anki
github_url: https://github.com/dae/anki
logo: anki.png
released: October 5, 2006
short_description: Anki is a free and open-source flashcard program that utilizes spaced repetition.
topic: anki
url: https://apps.ankiweb.net/index.html
wikipedia_url: https://en.wikipedia.org/wiki/Anki_(software)
---
Anki is a program which makes remembering things easy. Because it's a lot more
efficient than traditional study methods, you can either greatly decrease your
time spent studying, or greatly increase the amount you learn.
