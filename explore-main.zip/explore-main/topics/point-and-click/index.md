---
display_name: point-and-click
topic: point-and-click
aliases: point-n-click
related: scumm, 
short_description: A genre of video game.
---
Games where player typically controls their character through a point-and-click interface using a computer mouse.