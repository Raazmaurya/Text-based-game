---
display_name: escape-the-room
topic: escape-the-room
aliases: escape-the-room-game, room-escape, room-escape-game
related: point-and-click, adventure-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Escape_the_room
---
A subgenre of point-and-click adventure game which requires a player to escape from imprisonment by exploiting their surroundings.