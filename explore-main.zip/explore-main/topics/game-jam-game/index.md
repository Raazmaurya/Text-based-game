---
display_name: game-jam-game
topic: game-jam-game
aliases: jam-code
related: ludum-dare, global-game-jam, js13kgames, github-game-off, game-jam
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Game_jam
---
A game typically built by an individual or small team in a few hours to a few weeks as part of a game-building hackathon.