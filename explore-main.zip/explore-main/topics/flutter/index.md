---
display_name: Flutter
topic: flutter
github_url: https://github.com/flutter
logo: flutter.png
related: dart, flutter-plugin, flutter-apps
released: May 2017
short_description: Flutter is an open source mobile application development SDK created by Google.
url: https://flutter.dev/
wikipedia_url: https://en.wikipedia.org/wiki/Flutter_(software)
---
Flutter is an open source mobile application development SDK created by Google. It is used to develop applications for Android and iOS, as well as being the primary method of creating applications for Google Fuchsia.
