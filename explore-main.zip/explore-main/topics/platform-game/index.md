---
display_name: platform-game
topic: platform-game
aliases: platformer
related: metroidvania, action-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Platform_game
---
A genre of video game where players must jump and climb between suspended platforms while avoiding obstacles.