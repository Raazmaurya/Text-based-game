---
aliases: cplusplus, c-plus-plus, cpps, cpp98, cpp03, cpp11, cpp14, cpp17, cpp20, cpp0x, cpp1y, cpp1z, cpp2a, cplusplus-11
created_by: Bjarne Stroustrup
display_name: C++
logo: cpp.png
released: October 1985
short_description: C++ is a general purpose and object-oriented programming language.
topic: cpp
url: https://isocpp.org/
wikipedia_url: https://en.wikipedia.org/wiki/C%2B%2B
---
C++ is a popular and widely used mid-level language. It was designed as an extension of the C language.
