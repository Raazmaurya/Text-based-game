---
aliases: hms-core
created_by: HUAWEI-Mobile-Services-Core
display_name: hms
github_url: https://github.com/HMS-Core
logo: hms.png
short_description: HMS Core is an assortment of open device and cloud capabilities provided by HMS.
topic: hms
url: https://developer.huawei.com/consumer/en/hms
wikipedia_url: https://en.wikipedia.org/wiki/Huawei_Mobile_Services
---
HMS Core is an assortment of open device and cloud capabilities provided by HMS, dedicated to helping developers build high-quality apps with minimal hassle. Noteworthy capabilities include: Account Kit, In-App Purchases (IAP), Push Kit, Game Service, Location Kit, Map Kit, Ads Kit, and ML Kit.
