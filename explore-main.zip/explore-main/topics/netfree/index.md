---
created_by: magicode
display_name: Netfree
logo: netfree.png
released: November 2014
short_description: Netfree creates filters and safety measures from exposure to unwanted online content.
topic: netfree
url: https://netfree.link/
wikipedia_url: https://he.wikipedia.org/wiki/%D7%A0%D7%98%D7%A4%D7%A8%D7%99
---
Netfree is a non-profit organization that creates filters and safety measures from exposure to unwanted online content
