---
aliases: content-management-system, content-management
display_name: Content Management System
related: content-delivery, web-application, blog, blogging, writing, publishing
short_description: Software providing website authoring, collaboration, and administration tools.
topic: cms
wikipedia_url: https://en.wikipedia.org/wiki/Web_content_management_system
---
A content management system (CMS) is a piece of software which provides website authoring, collaboration, and administration tools that help users with little knowledge of programming languages create and manage website content.
