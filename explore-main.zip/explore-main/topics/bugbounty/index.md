---
display_name: Bug Bounty
related: bug-bounty,security,penetration-testing,pentesting,pentest
short_description: Deal by which individuals can receive recognition and compensation for reporting bugs.
topic: bugbounty
wikipedia_url: https://en.wikipedia.org/wiki/Bug_bounty_program
---
A bug bounty program is a deal offered by many websites, organizations and software developers by which individuals can receive recognition and compensation for reporting bugs, especially those pertaining to security exploits and vulnerabilities.
