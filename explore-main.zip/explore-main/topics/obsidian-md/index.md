---
topic: obsidian-md
display_name: Obsidian
aliases: obsidian
url: https://obsidian.md
github_url: https://github.com/obsidianmd
short_description: Obsidian is a note taking app that edits locally stored Markdown files.
logo: obsidian-md.png
created_by: Shida Li and Erica Xu
released: May 2020
---
Obsidian is a powerful knowledge base that works on top of a local folder of plain text Markdown files.
