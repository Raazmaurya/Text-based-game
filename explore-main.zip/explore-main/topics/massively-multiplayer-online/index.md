---
display_name: massively-multiplayer-online
topic: massively-multiplayer-online
aliases: mmo, mmog, massively-multiplayer-online-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Massively_multiplayer_online_game
---
An online game with large numbers of players typically featuring a huge, persistent open world.
