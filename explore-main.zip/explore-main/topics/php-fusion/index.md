---
aliases: phpfusion, php-fusion-cms, php-fusion-themes, php-fusion-infusions
created_by: PHP-Fusion Inc
display_name: PHP-Fusion
github_url: https://github.com/php-fusion
logo: php-fusion.png
released: April 12, 2003
short_description: PHP-Fusion is a lightweight open source content management system (CMS) written in PHP.
topic: php-fusion
url: https://www.php-fusion.co.uk/
wikipedia_url: https://en.wikipedia.org/wiki/PHP-Fusion
---
PHP-Fusion is an all in one integrated and scalable platform a lightweight open source content management system (CMS) written in PHP that will fit any purpose when it comes to website productions, whether you are creating community portals or personal sites.
