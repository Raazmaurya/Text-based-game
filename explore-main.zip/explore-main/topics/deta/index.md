---
created_by: Abstract Computing UG in Berlin
display_name: Deta
github_url: https://github.com/deta/
logo: deta.png
short_description: Projects using serverless hosting or NoSQL Databases by Deta.
topic: deta
url: https://www.deta.sh/
---
Deta offers serverless hosting, NoSQL databases, and file storage. For optimal usage, check out their Python, JavaScript, and Go SDKs.
