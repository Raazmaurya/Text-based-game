---
aliases:
created_by: Theo de Raadt
display_name: OpenBSD
github_url: https://github.com/openbsd
logo: openbsd.png
released: July 1996
short_description: OpenBSD is a FREE, multi-platform 4.4BSD-based UNIX-like operating system.
topic: openbsd
url: https://www.openbsd.org/
wikipedia_url: https://en.wikipedia.org/wiki/OpenBSD
---
OpenBSD is a FREE, multi-platform 4.4BSD-based UNIX-like operating system. Our
efforts emphasize portability, standardization, correctness, proactive security
and integrated cryptography.
