---
display_name: concourse-ci
topic: concourse-ci
github_url: https://github.com/concourse/concourse
logo: concourse-ci.png
short_description: It is most commonly used for CI/CD, and is built to scale to any kind of automation pipeline, from simple to complex.
url: https://concourse-ci.org/
---
Concourse CI/CD is an open source platform which runs on two main Docker containers. Once Concourse is installed, all you have to do is to use the docker-compose up command to bring up the Concourse server. Concourse uses Postgres as its database.

