---
display_name: 4x
topic: 4x
aliases: 4x-game, xxxx, 
related: command-and-conquer, real-time-strategy
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/4X
---
4X is a genre of strategy-based games, where players control an empire and "explore, expand, exploit, and exterminate".