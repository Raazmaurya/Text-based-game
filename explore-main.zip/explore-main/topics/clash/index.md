---
created_by: Dreamacro
display_name: Clash
github_url: https://github.com/Dreamacro/clash
logo: clash.png
topic: clash
short_description: A rule-based tunnel in Go.
---

A rule-based tunnel in Go. Provide you with powerful and fast network functions. Convenient for you to witness the larger network world.
