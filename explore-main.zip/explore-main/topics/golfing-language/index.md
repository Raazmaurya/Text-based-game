---
aliases: golflang
display_name: Golfing language
related: code-golf, programming-language
short_description: A programming language designed to be terse.
topic: golfing-language
---
A golfing language is a programming language, usually esoteric, that is designed to make programs written in it as terse as possible. These languages are usually used in Code Golf.
