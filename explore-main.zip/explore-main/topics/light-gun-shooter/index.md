---
display_name: light-gun-shooter
topic: light-gun-shooter
aliases: light-gun-shooter-game
related: duck-hunt, zapper
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Light_gun_shooter
---
A type of shooter video game genre in which the primary design element is aiming and shooting with a gun-shaped controller.