---
display_name: Netlify
short_description: Netlify is a continuous deployment powerful serverless platform.
topic: netlify
github_url: https://github.com/netlify
wikipedia_url: https://en.wikipedia.org/wiki/Netlify
logo: netlify.png
url: https://netlify.com
---

Netlify is a powerful serverless platform with an intuitive git-based workflow. 
Automated deployments, shareable previews, and much more.
