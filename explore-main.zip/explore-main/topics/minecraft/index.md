---
aliases: minecraft-mod, minecraft-plugin
created_by: Markus Persson, Jens Bergensten
display_name: Minecraft
logo: minecraft.png
released: November 18, 2011
short_description: Minecraft is a sandbox video game.
topic: minecraft
url: https://minecraft.net/en-us/
wikipedia_url: https://en.wikipedia.org/wiki/Minecraft
---
Published by Mojang, Minecraft is a game that allows its players virtually unlimited creative and building authority in their 3D cube world.
