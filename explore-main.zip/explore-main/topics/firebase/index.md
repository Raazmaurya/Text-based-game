---
created_by: James Tamplin, Andrew Lee
display_name: Firebase
github_url: https://github.com/firebase/
logo: firebase.png
released: April 2012
short_description: Firebase is a mobile app development platform that provides data
  analysis and database web services for developers.
topic: firebase
url: https://firebase.google.com/
wikipedia_url: https://en.wikipedia.org/wiki/Firebase
---
Firebase is a mobile app development platform that provides data analysis and database web services for developers. Firebase provides developers with an API that enables the integration of online statistical analysis and database communication into their applications.
