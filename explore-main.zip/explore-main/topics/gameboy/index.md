---
topic: gameboy
display_name: Game Boy
aliases: gb, gba, gbc, gameboy-color, gameboy-advance
related: assembly, cartridge, game-dev, retrogaming, nintendo
created_by: Gunpei Yokoi
released: April 21, 1989
short_description: The Game Boy was a line of handheld gaming devices created and sold by Nintendo.
wikipedia_url: https://en.wikipedia.org/wiki/Game_Boy
---
The Game Boy was a line of handheld gaming devices created and sold by Nintendo. Typically development of the Game Boy done today includes homebrew games, emulator building, and preserving code and coding techniques.
