---
display_name: Js13kGames
created_by: Andrzej Mazur
github_url: https://github.com/js13kGames
aliases: js13k
related: global-game-jam, game-off, ludum-dare
logo: js13kgames.png
short_description: Js13kGames is a month-long JavaScript coding competition, where entries are limited in file size to 13 kilobytes.
topic: js13kgames
url: http://js13kgames.com/
---
Js13kGames is a month-long JavaScript coding competition for HTML5 Game Developers, where entries are limited in file size to 13 kilobytes.
