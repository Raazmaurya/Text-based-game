---
aliases: hugo-theme
created_by: Bjørn Erik Pedersen
display_name: Hugo
github_url: https://github.com/gohugoio/hugo
logo: hugo.png
released: July 04, 2013
short_description: Hugo is one of the most popular open-source static site generators.
topic: hugo
url: https://gohugo.io/
---
Hugo is a fast and modern static site generator written in Go, and designed to make website creation fun again.
