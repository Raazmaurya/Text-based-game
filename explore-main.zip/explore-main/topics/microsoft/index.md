---
created_by: Bill Gates, Paul Allen
display_name: Microsoft
logo: microsoft.png
related: windows
github_url: https://github.com/microsoft
short_description: Microsoft is a company that develops and supports a range of software products, services, devices, and solutions.
released: April 4, 1975
url: https://www.microsoft.com
topic: microsoft
wikipedia_url: https://en.wikipedia.org/wiki/Microsoft
---
Microsoft Corporation is a technology company. The Company develops and supports a range of software products, services, devices, and solutions. The Company's segments include Productivity and Business Processes, Intelligent Cloud, and More Personal Computing. It also designs, manufactures, and sells devices, including personal computers (PCs), tablets, gaming and entertainment consoles, other intelligent devices, and related accessories.
