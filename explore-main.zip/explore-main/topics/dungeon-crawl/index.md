---
display_name: dungeon-crawl
topic: dungeon-crawl
aliases: dungeon-crawl-game, dungeon-crawler
related: roguelike, mud-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Dungeon_crawl
---
A type of scenario in fantasy role-playing games, where heroes navigate a dungeon, or dungeon-like environment, battling various monsters, avoiding traps, solving puzzles, looting treasure, etc.