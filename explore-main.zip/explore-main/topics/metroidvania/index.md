---
display_name: metroidvania
topic: metroidvania
aliases: metroidvania-game
related: action-adventure, action-adventure-game, platform-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Metroidvania
---
A subgenre of action-adventure video games combining game design and mechanics that are similar to Metroid and Castlevania.