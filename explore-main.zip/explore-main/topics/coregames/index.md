---
created_by: Manticore Games
display_name: CoreGames
github_url: https://github.com/ManticoreGamesInc/
logo: coregames.png
short_description: Core is a complete multiplayer development platform with tools for game editing, publishing, and discovery.
topic: coregames
url: https://www.coregames.com
---
Core is a complete multiplayer development platform with tools for game editing, publishing, and discovery using a Lua API and Unreal Engine.
