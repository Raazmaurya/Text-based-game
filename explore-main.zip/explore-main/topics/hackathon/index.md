---
topic: hackathon
aliases: hackfest, codefest, hackday
display_name: Hackathon
aliases: hackathons
related: game-jam, hacktoberfest, game-off, hackathon-kit, hackathon-organiser
short_description: A hackathon is a gathering where developers collaboratively code in an extreme manner over a short period of time.
wikipedia_url: https://en.wikipedia.org/wiki/Hackathon
---
A hackathon is a sprint-like event in which people collaborate intensively on software projects. The goal of a hackathon is to create usable software or hardware with the goal of creating a functioning product by the end of the event.
