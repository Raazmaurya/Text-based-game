---
display_name: interactive-film
topic: interactive-film
aliases: interative-movie, interactive-video, movie-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Interactive_film
---
A style if video game that presents its gameplay in a cinematic, scripted manner, often through the use of video or animation.