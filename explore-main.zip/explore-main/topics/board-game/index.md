---
display_name: board-game
topic: board-game
aliases: boardgame
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Board_game
---
A tabletop game that involves counters or pieces moved or placed on a pre-marked surface or board, according to a set of rules.