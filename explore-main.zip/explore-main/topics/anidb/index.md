---
display_name: AniDB
logo: anidb.png
released: 2002
related: anime, myanimelist, kitsu, animenewsnetwork, anilist, bangumi, annict, crunchyroll
short_description: AniDB is an online English anime-related database, forum, and tracker.
topic: anidb
url: https://anidb.net/
---
AniDB stands for Anime DataBase. AniDB is a non-profit anime database that is open freely to the public. This means that all users have the ability to add or edit information on AniDB. The site features detailed information about all forms of CJK (Chinese, Japanese, and Korean) animation.
