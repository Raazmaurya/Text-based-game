---
display_name: Amazon Web Services
topic: aws
github_url: https://github.com/aws
logo: aws.png
related: amazon
released: March 2006
short_description: Amazon Web Services provides on-demand cloud computing platforms on a subscription basis.
url: https://aws.amazon.com/
wikipedia_url: https://en.wikipedia.org/wiki/Amazon_Web_Services
---
Amazon Web Services is a subsidiary of Amazon.com that provides on-demand cloud computing platforms to individuals, companies, and governments, on a subscription basis.
