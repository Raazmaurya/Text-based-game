---
display_name: music-game
topic: music-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Music_video_game
---
A genre of video game where the gameplay is meaningfully and often almost entirely oriented around the player's interactions with a musical score or individual songs.