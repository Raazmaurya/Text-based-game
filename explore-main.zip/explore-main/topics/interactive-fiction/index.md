---
display_name: interactive-fiction
topic: interactive-fiction
aliases: if
related: visual-novel, text-adventure
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Interactive_fiction
---
Software simulating environments in which players use text commands to control characters and influence the environment.