---
aliases: linux-kernel, linux-app, linux-distribution, linux-desktop
created_by: Linus Torvalds
display_name: Linux
github_url: https://github.com/torvalds/linux
logo: linux.png
released: September 17, 1991
short_description: Linux is an open source kernel.
topic: linux
wikipedia_url: https://en.wikipedia.org/wiki/Linux
---
Linux is an open source kernel modeled after UNIX. Widely used, it is known for its efficiency and reliability.
