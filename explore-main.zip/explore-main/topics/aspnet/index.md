---
aliases: asp-net, aspnet-core
created_by: Microsoft
display_name: ASP.NET
logo: aspnet.png
released: January 2002
short_description: ASP.NET is a web framework for building modern web apps and services.
topic: aspnet
url: https://asp.net
wikipedia_url: https://en.wikipedia.org/wiki/ASP.NET
---
ASP.NET is an open source web framework for building modern web apps and services with .NET. ASP.NET creates websites based on HTML5, CSS, and JavaScript that are simple, fast, and can scale to millions of users.
