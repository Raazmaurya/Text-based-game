---
aliases: postgres
created_by: Michael Stonebraker
display_name: PostgreSQL
github_url: https://github.com/postgres/postgres
logo: postgresql.png
released: July 8, 1996
short_description: PostgreSQL is an open source database system.
topic: postgresql
url: https://www.postgresql.org/
wikipedia_url: https://en.wikipedia.org/wiki/PostgreSQL
---
PostgreSQL is a database management system that is object-relational. PostgreSQL originated from the Ingres project at the University of California, Berkeley.
