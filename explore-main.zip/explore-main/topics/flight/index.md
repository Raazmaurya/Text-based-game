---
created_by: Mike Cao
aliases: flight-php, flightphp
display_name: Flight
github_url: https://github.com/mikecao/flight
short_description: Flight is a fast, simple, extensible framework for PHP.
topic: flight
url: https://flightphp.com/
---

Flight is a fast, simple, extensible framework for PHP. Flight enables you to quickly and easily build RESTful web applications.
