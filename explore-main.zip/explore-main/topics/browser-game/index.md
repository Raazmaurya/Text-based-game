---
display_name: browser-game
topic: browser-game
aliases: pbbg, browser-based-game, persisant-browser-based-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Browser_game
---
A video game that you can play from the comfort of your browser.