---
aliases: bannerlord, bannerlord-mod
created_by: TaleWorlds Entertainment
display_name: 'Mount & Blade II: Bannerlord'
logo: mount-and-blade-bannerlord.png
released: March 30, 2020
short_description: 'Mount & Blade II: Bannerlord is a strategy/action role-playing game.'
topic: mount-and-blade-bannerlord
url: https://www.taleworlds.com/en/Games/Bannerlord
wikipedia_url: https://en.wikipedia.org/wiki/Mount_%26_Blade_II:_Bannerlord
---
Published by TaleWorlds Entertainment, Mount & Blade II: Bannerlord is the eagerly awaited sequel to the acclaimed medieval combat simulator and role-playing game Mount & Blade: Warband.
