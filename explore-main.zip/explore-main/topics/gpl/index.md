---
aliases: gplv2, gplv3, gnu-public-license, gnu-general-public-license
display_name: GNU General Public License
short_description: GNU General Public License is a free software license published by the Free Software Foundation.
topic: gpl
wikipedia_url: https://en.wikipedia.org/wiki/GNU_General_Public_License
---
GNU General Public License is a free software license published by the Free Software Foundation whose main terms guarantee users the freedom to share and change the software.
