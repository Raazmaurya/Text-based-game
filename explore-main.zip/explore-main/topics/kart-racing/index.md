---
display_name: kart-racing
topic: kart-racing
aliases: cart-racing, cart-racing-game, kart-racing-game, go-kart-racing-game, go-kart-racing
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Kart_racing_game
---
A subgenre of racing video games that have simplified driving mechanics and typically include unusual racetrack designs, obstacles, vehicular combat, and/or humor.