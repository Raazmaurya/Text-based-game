---
display_name: EPITECH
short_description: EPITECH is a French graduate school teaching computer sciences.
topic: epitech
logo: epitech.png
url: https://epitech.eu
wikipedia_url: https://en.wikipedia.org/wiki/Epitech
---
The Paris Graduate School of Digital Innovation (French: École pour l'informatique et les nouvelles technologies, or EPITECH), formerly European Institute of Information Technology in English, is a private institution of higher education in general computer science that was founded in 1999. (Text taken from Wikipedia)
