---
aliases: nano-currency, raiblocks
created_by: Nano Foundation
display_name: Nano
github_url: https://github.com/nanocurrency
logo: nanocurrency.png
released: October 4, 2015
short_description: Nano is a fast and feeless cryptocurrency developed by the Nano Foundation.
topic: nanocurrency
related: blockchain, cryptocurrency
url: https://nano.org
wikipedia_url: https://en.wikipedia.org/wiki/Nano_(cryptocurrency)
---
Nano is decentralized, sustainable, and secure digital money focused on addressing the inefficiencies present in existing financial systems.
