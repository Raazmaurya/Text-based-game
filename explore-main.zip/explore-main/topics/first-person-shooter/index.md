---
display_name: first-person-shooter
topic: first-person-shooter
aliases: fps, first-person-shooter-game
related: third-person-shooter, tactical-shooter
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/First-person_shooter
---
A video game genre centered on gun and other weapon-based combat experienced through the eyes of the protagonist.