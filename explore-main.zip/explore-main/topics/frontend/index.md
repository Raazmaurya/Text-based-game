---
aliases: frontend-developer
display_name: Front end
short_description: Front end is the programming and layout that people see and interact
  with.
topic: frontend
wikipedia_url: https://en.wikipedia.org/wiki/Front-end_web_development
---
Front-end development is the process of producing HTML, CSS, and JavaScript for web application visuals and interactions. Basically it is a language that is executed in client.
