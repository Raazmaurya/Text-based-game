---
display_name: battle-royale
topic: battle-royale
aliases: battle-royale-game
related: fortnite, pubg, apex-legends
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Battle_royale_game
---
A battle royale game is an online multiplayer video game genre that blends the survival, exploration, and scavenging elements of a survival game with last-man-standing gameplay.