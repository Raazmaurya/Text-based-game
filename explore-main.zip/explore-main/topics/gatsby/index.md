---
aliases: gatsbyjs, gatsby-js
created_by: Kyle Mathews & Sam Bhagwat
display_name: gatsby
github_url: https://github.com/gatsbyjs/gatsby
logo: gatsby.png
related: react, open-source-framework
released: 2015
short_description: Gatsby is a free and open source framework based on React that helps developers build blazing fast websites and apps.
topic: gatsby
url: https://www.gatsbyjs.org/
---
Gatsby is a free and open source framework based on React that helps developers build blazing-fast websites and apps.
It helps towards website development working with headless CMS's for modern tooling.
