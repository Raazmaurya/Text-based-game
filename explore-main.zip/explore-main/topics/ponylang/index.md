---
aliases: pony-language
created_by: Sylvan Clebsch
display_name: Pony
github_url: https://github.com/ponylang
logo: ponylang.png
related: actor-model, programming-language
released: 2015
short_description: Pony is an open source, object-oriented, actor-model, capabilities-secure, high-performance programming language.
topic: ponylang
url: https://ponylang.io
---
Pony is an open source, object-oriented, actor-model, capabilities-secure, high-performance programming language. It makes it easy to write fast, safe, efficient, highly concurrent programs.
