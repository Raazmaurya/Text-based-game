---
created_by: Garrett Gyssler
display_name: MyAnimeList
logo: myanimelist.png
released: April 6, 2006
related: mal, my-anime-list, myanimelist-api
short_description: MyAnimeList is an online forum and anime-manga database.
topic: myanimelist
url: https://myanimelist.net/
wikipedia_url: https://en.wikipedia.org/wiki/MyAnimeList
---
MyAnimeList, often abbreviated as MAL, is an online forum and anime-manga database. The site provides its users with a list-like system to organize and score anime and manga.