---
aliases: nuxtjs
created_by: Sébastien Chopin & Alexandre Chopin
display_name: Nuxt.js
github_url: https://github.com/nuxt/nuxt.js
logo: nuxt.png
related: javascript, vue, ssr, spa
released: November 2016
short_description: Nuxt.js is a Vue.js Meta Framework to create complex, fast & universal web applications quickly.
topic: nuxt
url: https://nuxtjs.org
wikipedia_url: https://en.wikipedia.org/wiki/Nuxt.js
---
Nuxt.js is a framework for creating Vue.js applications. You can choose between Universal, Static Generated or Single Page applications.
