---
display_name: action-game
topic: action-game
related: action-adventure-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Action_game
---
A video game genre that emphasizes physical challenges, including hand–eye coordination and reaction-time.