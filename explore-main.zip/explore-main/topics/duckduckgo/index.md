---
topic: duckduckgo
github_url: https://github.com/duckduckgo
display_name: DuckDuckGo
logo: duckduckgo.png
short_description: DuckDuckGo is an Internet search engine that prioritizes privacy by not tracking users.
url: https://duckduckgo.com/
wikipedia_url: https://en.wikipedia.org/wiki/DuckDuckGo
---
DuckDuckGo is an Internet search engine that emphasizes protecting searchers' privacy and avoiding the filter bubble of personalized search results.
