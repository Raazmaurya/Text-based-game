---
display_name: adventure-game
topic: adventure-game
aliases: adventure
related: action-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Adventure_game
---
A video game in which the player assumes the role of a protagonist in an interactive story driven by exploration and puzzle-solving