---
aliases: assembler, assembly-language
created_by: Kathleen Booth
display_name: Assembly
logo: assembly.png
related: c, cpp, operating-system
released: '1949'
short_description: Assembly is a low-level programming language.
topic: assembly
wikipedia_url: https://en.wikipedia.org/wiki/Assembly_Language
---
Assembly is a low-level programming language in which there is a very strict correspondence between language instructions and architecture machine code instructions.
