---
created_by: Neo4j, Inc.
display_name: Neo4j
github_url: https://github.com/neo4j/neo4j
logo: neo4j.png
related: graph, database, nosql
released: '2007'
short_description: Neo4j is a graph database management system.
topic: neo4j
url: https://neo4j.com/
wikipedia_url: https://en.wikipedia.org/wiki/Neo4j
---
Neo4j is a graph database management system. It is highly flexible, highly scalable, and uses the Cypher query language to take advantage of its graph-based method of structuring data.
