---
display_name: Pixel Art
aliases: pixelart
related: pixel, pixels, sprite, sprites, spritesheet, spritesheets
short_description: Pixel art is a form of digital art where images are created and edited at the pixel level.
topic: pixel-art
wikipedia_url: https://en.wikipedia.org/wiki/Pixel_art
---
Pixel art is a form of digital art, where images are edited on the pixel level. The aesthetic for these kind of graphics comes from 8-bit and 16-bit computers and video game consoles.
