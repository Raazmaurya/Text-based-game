---
aliases: onlinejudge
display_name: Online Judge
short_description: An Online Judge is an online system to test programs in programming contests like ICPC.
topic: online-judge
wikipedia_url: https://en.wikipedia.org/wiki/Online_judge
---
An online judge is an online system to test programs in programming contests. They are also used to practice for such contests like ICPC. The system can compile and execute your code, and test your code with pre-constructed data. Submitted code may be run with restrictions, including time limit, memory limit, security restriction, and so on. The output of the code will be captured by the system, and compared with the standard output. The system will then return the result.
