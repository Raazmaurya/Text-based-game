---
aliases: collaborative-mapping
created_by: Steve Coast
display_name: OpenStreetMap
logo: openstreetmap.png
released: August 9, 2004
short_description: OpenStreetMap is a collaborative project to create a free editable map of the world.
topic: openstreetmap
url: https://osm.org/
related: mapillary, mapbox
wikipedia_url: https://en.wikipedia.org/wiki/OpenStreetMap
---
OpenStreetMap provides map data for thousands of web sites, mobile apps, and hardware devices.