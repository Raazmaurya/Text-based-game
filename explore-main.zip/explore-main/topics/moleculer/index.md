---
created_by: icebob
display_name: Moleculer
github_url: https://github.com/moleculerjs/moleculer
logo: moleculer.png
related: microservices, distributed-systems, microservice-framework
aliases: moleculerjs, moleculer-framework
released: February 17, 2017
short_description: Progressive microservices framework.
topic: moleculer
url: https://moleculer.services/
---
Moleculer is a fast, modern and powerful microservices framework for Node.js. It helps you to build efficient, reliable and scalable services. Moleculer provides many features for building and managing your microservices.
