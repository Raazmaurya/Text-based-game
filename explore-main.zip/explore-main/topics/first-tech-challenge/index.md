---
aliases: ftc, first-ftc, ftc-robot-controller, ftc-sdk
created_by: FIRST
display_name: FIRST Tech Challenge
github_url: https://github.com/ftctechnh
logo: first-tech-challenge.png
short_description: FIRST Tech Challenge (FTC) is a robotics competition for 7-12th graders where teams compete head-to-head in annual challenges.
topic: first-tech-challenge
url: https://www.firstinspires.org/robotics/ftc
wikipedia_url: https://en.wikipedia.org/wiki/FIRST_Tech_Challenge
---

FIRST Tech Challenge (FTC) is a robotics competition for students in grades 7–12 to compete head to head, using a sports model. Teams are responsible for designing, building, and programming their robots in a 10-week build period to compete in an alliance format against other teams.
