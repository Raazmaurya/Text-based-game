---
aliases: glams
display_name: GLAM
short_description: GLAM is an acronym for "galleries, libraries, archives, and museums".
topic: glam
wikipedia_url: https://en.wikipedia.org/wiki/GLAM_(industry)
---
GLAM is an acronym for "galleries, libraries, archives, and museums", and refers to cultural institutions with a mission to provide access to knowledge. GLAMs collect and maintain cultural heritage materials in the public interest.
