---
created_by: Google
display_name: Google Maps
logo: google-maps.png
related: maps, google, google-maps-api
github_url: https://github.com/googlemaps/
short_description: Google Maps is a web mapping platform and consumer application offered by Google.
released: February 8, 2005
url: https://maps.google.com/
topic: google-maps
wikipedia_url: https://en.wikipedia.org/wiki/Google_Maps
---
Google Maps is a web mapping platform and consumer application offered by Google. It offers satellite imagery, aerial photography, street maps, 360° interactive panoramic views of streets, real-time traffic conditions, and route planning for traveling by foot, car, air and public transportation.
