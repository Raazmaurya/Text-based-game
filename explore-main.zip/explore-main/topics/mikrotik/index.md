---
display_name: MikroTik
related: routerboard, routeros
short_description: MikroTik is a Latvian network equipment manufacturer.
topic: mikrotik
logo: mikrotik.png
url: https://mikrotik.com/
wikipedia_url: https://en.wikipedia.org/wiki/MikroTik
---
The company develops and sells wired and wireless network routers, network switches, access points, as well as operating systems, and auxiliary software.
