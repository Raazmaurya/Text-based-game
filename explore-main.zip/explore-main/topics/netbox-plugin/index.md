---
aliases: netbox-plugins
created_by: NetBox Community
display_name: NetBox Plugin
github_url: https://github.com/netbox-community/netbox
logo: netbox-plugin.png
related: netbox
released: April 13 2020
short_description: NetBox plugins can be used to extend NetBox's functionality beyond what the core product provides.
topic: netbox-plugin
url: https://netbox.readthedocs.io/en/stable/plugins/
---
In version 2.8.0, NetBox released the plugin feature.  NetBox plugins can be used to extend NetBox's functionality beyond what the core product provides.
