---
display_name: life-simulator
topic: life-simulator
aliases: life-simulator-game
related: god-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Life_simulation_game
---
A subgenre of simulation video games, where the player lives or controls one or more virtual lifeforms.