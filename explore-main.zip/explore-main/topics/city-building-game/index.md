---
display_name: city-building-game
topic: city-building-game
aliases: city-building, town-building, town-building-game
related: sim-city, simulator
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/City-building_game
---
A genre of simulation video game where players act as the overall planner and leader of a city or town, looking down on it from above, and being responsible for its growth and management strategy.