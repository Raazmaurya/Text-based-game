---
related: php
created_by: Daniel Lowrey
display_name: Amp
github_url: https://github.com/amphp
logo: amphp.png
released: August 05, 2013
short_description: Amp is a non-blocking concurrency framework for PHP.
topic: amphp
url: https://amphp.org/
---
Amp is a non-blocking concurrency framework for PHP. It provides an event loop, promises, and streams as a base for asynchronous programming.
