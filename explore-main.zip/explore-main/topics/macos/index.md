---
aliases: macosx, macos-sierra, macos-app, mac-osx, mac
created_by: Apple
display_name: macOS
logo: macos.png
released: March 24, 2001
short_description: macOS is Apple's operating system.
topic: macos
url: https://www.apple.com/macos/
wikipedia_url: https://en.wikipedia.org/wiki/MacOS
---
macOS is the operating system that powers every Mac computer. It was designed by Apple and is meant specifically for their hardware.
