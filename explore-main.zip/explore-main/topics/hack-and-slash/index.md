---
display_name: hack-and-slash
topic: hack-and-slash
aliases: hack-n-slash, hack-and-slash-game, hack-n-slash-game, hack-and-slay-game, hack-n-slay, hack-n-slay-game
related: role-playing-game,mud, mmorpg
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Hack_and_slash
---
A type of gameplay in tabletop and video games emphasizing combat.
