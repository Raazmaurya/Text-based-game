---
aliases: fabric, fabric-mod, fabricmc-mod, minecraft-fabric-mod, minecraft-fabric
created_by: FabricMC Contributors
display_name: FabricMC
github_url: https://github.com/FabricMC/
logo: fabricmc.png
related: minecraft, minecraft-mod
released: December 20, 2018
short_description: Next generation, highly modular and open Minecraft modding API.
topic: fabricmc
url: https://fabricmc.net
---
Fabric is a lightweight, experimental modding toolchain for Minecraft.