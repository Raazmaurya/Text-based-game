---
created_by: Microsoft
display_name: Azure
github_url: https://github.com/Azure
logo: azure.png
released: February 1, 2010
short_description: Azure is a cloud computing service created by Microsoft.
topic: azure
url: https://azure.microsoft.com/
wikipedia_url: https://en.wikipedia.org/wiki/Microsoft_Azure
---

Azure is a cloud computing service created by Microsoft for building, testing, deploying, and managing applications and services through a global network of Microsoft-managed data centers.