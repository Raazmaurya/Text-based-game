---
aliases: golang, golang-examples
created_by: Robert Griesemer, Rob Pike, Ken Thompson
display_name: Go
github_url: https://github.com/golang/go
logo: go.png
related: language, c
released: November 10, 2009
short_description: Go is a programming language built to resemble a simplified version
  of the C programming language.
topic: go
url: https://golang.org/
wikipedia_url: https://en.wikipedia.org/wiki/Go_(programming_language)
---
Go is a programming language built to resemble a simplified version of the C programming language. It compiles at the machine level. Go was created at Google in 2007 by Robert Griesemer, Rob Pike, and Ken Thompson.
