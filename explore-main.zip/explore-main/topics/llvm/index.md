---
created_by: Vikram Adve, Chris Lattner
display_name: LLVM
github_url: https://github.com/llvm/llvm-project
released: 2019
short_description: The LLVM compiler infrastructure project is a set of compiler and toolchain technologies.
topic: llvm
wikipedia_url: https://en.wikipedia.org/wiki/LLVM
---
The LLVM compiler infrastructure project is a set of compiler and toolchain technologies, which can be used to develop a front end for any programming language and a back end for any instruction set architecture.

