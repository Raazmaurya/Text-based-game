---
display_name: action-adventure
topic: action-adventure
aliases: action-adventure-game
related: action-game, adventure-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Action-adventure_game
---
A video game genre that combines core elements from both the action game and adventure game genres.