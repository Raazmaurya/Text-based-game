---
related: php
created_by: Sebastian Bergmann
display_name: PHPUnit
github_url: https://github.com/sebastianbergmann/phpunit
released: March 15, 2004
short_description: PHPUnit is a programmer-oriented testing framework for PHP.
topic: phpunit
url: https://phpunit.de/
wikipedia_url: https://en.wikipedia.org/wiki/PHPUnit
---
PHPUnit is a unit testing framework for the PHP programming language. It is an instance of the xUnit architecture for unit testing frameworks.