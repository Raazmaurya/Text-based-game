---
aliases: next, next-js
created_by: Vercel
display_name: Next
github_url: https://github.com/vercel/next.js
logo: nextjs.png
released: October 25, 2016
short_description: Next.js is an open source React front-end development web framework.
topic: nextjs
url: https://nextjs.org/
wikipedia_url: https://en.wikipedia.org/wiki/Next.js
---

Next.js is an open source React front-end development web framework that enables functionality such as server-side rendering and generating static websites for React-based web applications.
