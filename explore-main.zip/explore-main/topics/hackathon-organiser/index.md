---
topic: hackathon-organiser
aliases: event-organiser, hack-organiser, hack-organizer, event-organizer
display_name: Hackathon-Organiser
related: game-jam, hacktoberfest, game-off, hackathon-kit, hackathon, hackathons
short_description: A person who organises or runs hackathons.
wikipedia_url: https://en.wikipedia.org/wiki/Hackathon
---

A person who organises or runs hackathons. This person is usually looking for resources or sponsorship to help them organise their hack.
