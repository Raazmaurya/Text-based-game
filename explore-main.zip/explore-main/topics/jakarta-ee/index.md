---
aliases: jakartaee
created_by: Eclipse Foundation
display_name: Jakarta EE
github_url: https://github.com/jakartaee/
logo: jakarta-ee.png
related: framework, webservices, cloud-native, application-server
released: September 2017
short_description: Open source cloud native Java.
topic: jakarta-ee
url: https://jakarta.ee
wikipedia_url: https://en.wikipedia.org/wiki/Jakarta_EE
---
Jakarta EE represents the best way to drive cloud-native, mission critical applications and build upon the decades of experience of real world deployments and developers.
