---
aliases: es6, es6-javascript, es6-tutorial
created_by: Brendan Eich, Ecma International
display_name: ECMAScript
github_url: https://github.com/tc39
logo: ecmascript.png
short_description: ECMAScript is the standards organization behind JavaScript.
topic: ecmascript
url: http://www.ecma-international.org/
wikipedia_url: https://en.wikipedia.org/wiki/ECMAScript
---
ECMAScript is the standardization of the family of scripting languages that includes JavaScript. New versions of the standard are released every year.
