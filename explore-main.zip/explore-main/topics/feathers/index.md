---
aliases: feathersjs, feathers-js
created_by: David Luecke
display_name: Feathers
github_url: https://github.com/feathersjs
logo: feathers.png
released: November 19, 2011
short_description: FeathersJS is a framework for real-time applications and REST APIs.
topic: feathers
url: https://feathersjs.com/
---
FeathersJS is a framework for real-time applications and REST APIs with JavaScript and TypeScript.
