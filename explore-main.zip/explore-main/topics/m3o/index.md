---
display_name: Micro
topic: m3o
github_url: https://github.com/micro
logo: m3o.png
related: microservices, cloud, distributed-systems
released: January 2015
short_description: Micro is a cloud native development platform.
url: https://m3o.com
---
Micro is an open source cloud native development platform which enables companies to build cloud services and distributed systems.
