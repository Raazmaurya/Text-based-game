---
display_name: flight-simulator
topic: flight-simulator
aliases: flight-simulation, flight-simulator-game, flight-simulation-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Flight_simulator
---
Software that artificially re-creates aircraft flight and the environment in which it flies.