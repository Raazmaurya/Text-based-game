---
aliases: md, markdown-editor
created_by: John Gruber
display_name: Markdown
logo: markdown.png
released: March 19, 2004
short_description: Markdown is a lightweight markup language.
topic: markdown
url: https://daringfireball.net/projects/markdown/
wikipedia_url: https://en.wikipedia.org/wiki/Markdown
---
Markdown is a lightweight markup language. It is designed to be a simple, lightweight way to add formatting without prior HTML experience.
