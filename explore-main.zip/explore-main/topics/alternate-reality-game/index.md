---
display_name: alternate-reality-game
topic: alternate-reality-game
aliases: alternate-reality, arg
related: virtual-reality
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Alternate_reality_game
---
An interactive networked narrative that uses the real world as a platform and employs transmedia storytelling to deliver a story that may be altered by the player actions.
