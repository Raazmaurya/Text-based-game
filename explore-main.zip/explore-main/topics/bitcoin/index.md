---
aliases: bitcoin-wallet, bitcoins, bitcoin-payment
created_by: Satoshi Nakamoto
display_name: Bitcoin
github_url: https://github.com/bitcoin/bitcoin
logo: bitcoin.png
released: January 3, 2009
short_description: Bitcoin is a cryptocurrency developed by Satoshi Nakamoto.
topic: bitcoin
url: https://bitcoin.org/en/
wikipedia_url: https://en.wikipedia.org/wiki/Bitcoin
---
Bitcoin is a cryptocurrency developed by Satoshi Nakamoto in 2009. Bitcoin is used as a digital payment system. Rather than use traditional currency (USD, YEN, EURO, etc.) individuals may trade in, or even mine Bitcoin. It is a peer-to-peer system, and transactions may take place between users directly.
