---
topic: nasa
github_url: https://github.com/nasa
display_name: NASA
logo: nasa.png
short_description: The National Aeronautics and Space Administration (NASA) is a government agency responsible for space research and development.
url: https://nasa.gov
wikipedia_url: https://en.wikipedia.org/wiki/NASA
---
NASA stands for National Aeronautics and Space Administration. NASA is a U.S. government agency that is responsible for science and technology related to air and space. The Space Age started in 1957 with the launch of the Soviet satellite Sputnik.
