---
aliases: discordjs, djs, discord-js-bot
topic: discord-js
display_name: Discord.JS
logo: discord-js.png
github_url: https://github.com/discordjs/discord.js
short_description: Discord.JS is a powerful Node.js module that allows you to easily interact with the Discord API.
url: https://discord.js.org/
---
Discord.JS is a powerful node.js module that allows you to interact with the Discord API very easily. It takes a much more object-oriented approach than most other libraries, making your bot's code significantly tidier and easier to comprehend.