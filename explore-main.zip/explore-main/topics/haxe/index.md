---
aliases: hx, hxml
created_by: Nicolas Cannasse, Haxe Foundation
display_name: Haxe
github_url: https://github.com/HaxeFoundation
released: '2005'
short_description: A metalanguage resembling ECMAScript which can be transpiled into a variety of languages.
topic: haxe
url: https://haxe.org/
wikipedia_url: https://en.wikipedia.org/wiki/Haxe
related: javascript, python, java, actionscript, c-plus-plus, csharp, php, lua
---
A language resembling ECMAScript much which can be transpiled into ActionScript3, JavaScript, Java, C++, C#, PHP, Python, and Lua.
