---
aliases: pocketmine-mp, pocketmine, pocketmine-plugin, pocketmine-plugins, pocketmine-mp-plugin, pmmp-plugin
created_by: Shoghi Cervantes Pueyo, pmmp
display_name: PocketMine-MP
github_url: https://github.com/pmmp/
logo: pmmp.png
related: mcpe, mcbe, minecraft, mcpe-server, bedrock-edition, bedrock, pmmp-virion, pmmp-game
released: 2012
short_description: A server software for Minecraft Bedrock Edition in PHP.
topic: pmmp
url: https://pmmp.io/
---
PocketMine-MP is a Minecraft: Bedrock Edition server software written in PHP, originally created by Shoghi Cervantes Pueyo, which can be enhanced and customised via plugins. Since the development on the main repository has stopped, the repository was forked and is currently maintained by members of pmmp.
