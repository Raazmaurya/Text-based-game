---
aliases: altium
created_by: Altium
display_name: "Altium Designer"
logo: altium-designer.png
released: 2005
short_description: "Altium Designer is a PCB and electronic design automation software package for printed circuit boards."
topic: altium-designer
url: https://www.altium.com/
wikipedia_url: https://en.wikipedia.org/wiki/Altium_Designer
---
The industry’s leading PCB design software combining schematic, layout, and everything else you need in one environment to effortlessly design printed circuit boards.