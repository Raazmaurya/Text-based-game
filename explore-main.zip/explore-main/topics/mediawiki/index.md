---
aliases: mediawiki-api
created_by: Wikimedia Foundation and MediaWiki contributors
display_name: MediaWiki
github_url: https://github.com/wikimedia/mediawiki
logo: mediawiki.png
released: January 25, 2002
short_description: MediaWiki is a free and open source wiki engine, most well-known for powering Wikipedia.
topic: mediawiki
url: https://www.mediawiki.org/
wikipedia_url: https://en.wikipedia.org/wiki/MediaWiki
---
MediaWiki is a popular free and open source wiki engine written in PHP.
It is used by tens of thousands of websites to collect and organize knowledge and make it available to people.
Many people may be familiar with MediaWiki as the software that runs Wikimedia sites such as Wikipedia.
