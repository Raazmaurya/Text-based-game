---
display_name: mud-game
topic: mud-game
aliases: mud, multi-user-dungeon, multiple-user-dungeon
related: old-school, text-adventure, roguelike, mudlet
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/MUD
---
A MUD (Multi-User Dungeon) is a multiplayer real-time virtual world, usually text-based, combining elements of role-playing games, hack and slash, player versus player, interactive fiction, and online chat.
