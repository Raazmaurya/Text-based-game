---
display_name: fantasy-game
topic: fantasy-game
related: fighting-fantasy, cyoa, choose-you-own-adventure
short_description: A genre of video game.
---
A genre of game, where players assume the roles of characters and act out fantastical adventures.