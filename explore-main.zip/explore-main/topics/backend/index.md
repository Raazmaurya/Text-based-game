---
aliases: backend-developer
display_name: Back end
short_description: Back end is the programming that handles the behind-the-scenes of a website or application that people do not see.
topic: backend
wikipedia_url: https://en.wikipedia.org/wiki/Front_end_and_back_end
---
Back end is the programming that handles the behind-the-scenes of a website or application that people do not see, such as the server and database. Programming languages such as Python, Ruby, and PHP is used for back-end development.
