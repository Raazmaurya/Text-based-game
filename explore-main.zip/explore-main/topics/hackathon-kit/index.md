---
topic: hackathon-kit
aliases: hack-kit, resources, resource
display_name: Hackathon-Kit
related: game-jam, hacktoberfest, game-off, hackathon-organiser, hackathon, hackathons
short_description: A kit or resource for hackathons.
wikipedia_url: https://en.wikipedia.org/wiki/Hackathon
---

A resources kit for hackathon organisers to draw on when organising their hackathons.
