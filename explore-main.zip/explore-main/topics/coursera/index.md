---
created_by: Andrew Ng, Daphne Koller
display_name: Coursera
logo: coursera.png
released: April 2012
short_description: Coursera is an online-learning platform that offers massive open online courses (MOOCs), Specializations, and Degrees.
topic: coursera
url: https://www.coursera.org/
wikipedia_url: https://en.wikipedia.org/wiki/Coursera
---
Coursera is an online-learning platform that offers MOOCs, Specializations, and Degrees across a wide range of domains and topics, such as 
Machine Learning, Philosophy, Marketing Essentials, Copywriting, etc.
