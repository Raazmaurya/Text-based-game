---
display_name: incremental-game
topic: incremental-game
aliases: idle-game, clicker-game, clicking-game, clicker
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Incremental_game
---
As genre of video games, where players performing simple actions such as clicking on the screen repeatedly to earn points or currency.