---
aliases: iris-golang, iris-framework, iris-go, iris12
created_by: Gerasimos Maropoulos
display_name: Iris
github_url: https://github.com/kataras/iris
logo: iris.png
related: framework, go
released: March 2016
short_description: Web framework for Go Developers.
topic: iris
url: https://iris-go.com
---
Iris is a free, open source, cross platform backend web framework intended for the development of modern web applications.
