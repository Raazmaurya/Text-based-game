---
aliases: npmjs, npm-package
created_by: Isaac Z. Schlueter
display_name: npm
github_url: https://github.com/npm
logo: npm.png
released: January 12, 2010
short_description: npm is a package manager for JavaScript included with Node.js.
topic: npm
url: https://www.npmjs.com/
wikipedia_url: https://en.wikipedia.org/wiki/Npm_(software)
---
Npm is a package manager for JavaScript, included with Node.js. As a package manager, npm makes it easy for developers to share and reuse code.
