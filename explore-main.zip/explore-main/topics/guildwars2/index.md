---
aliases: guildwars-2, gw2, guild-wars-2, guildwarstwo
created_by: ArenaNet
display_name: Guild Wars 2
logo: guildwars2.png
released: August 28, 2012
short_description: Guild Wars 2 is an MMORPG in the world of Tyria, following up the story from Guild Wars.
topic: guildwars2
url: https://www.guildwars2.com/
wikipedia_url: https://en.wikipedia.org/wiki/Guild_Wars_2
---
Guild Wars 2 is a massively multiplayer online role-playing game developed by ArenaNet and published by NCSOFT. Set in the fantasy world of Tyria, the game follows the re-emergence of Destiny's Edge, a disbanded guild dedicated to fighting the Elder Dragons, a Lovecraftian species that has seized control of Tyria in the time since the original Guild Wars. The game takes place in a persistent world with a story that progresses in instanced environments.