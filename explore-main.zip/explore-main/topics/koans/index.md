---
topic: koans
display_name: Koans
short_description: Koans are collections of exercices intended to help you learn a programming language.
---
In programming Koans are exercises, puzzles, or problems - typically presented as a suite of unit tests - intended to get developers up to speed with the idioms and features of a programming language.
